#ifndef __BSEA__
#define __BSEA__

int binsearch(int *v, int n, int x);

#endif

